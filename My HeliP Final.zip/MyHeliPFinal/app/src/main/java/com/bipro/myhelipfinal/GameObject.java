package com.bipro.myhelipfinal;


import android.graphics.Canvas;

public abstract class GameObject {

    public enum GameObjectID {ENEMY, HELPER, PLAYER, BULLET, MEDIC, BARRIER,BACKGROUND}

    protected int posX, posY, speedX, speedY, sizeX, sizeY;
    protected GameObjectID id;

    protected GameObject(int posX, int posY, GameObjectID id, int sizeX, int sizeY) {
        this.posX = posX;
        this.posY = posY;
        this.id = id;
        this.sizeX = sizeX;
        this.sizeY = sizeY;

        this.speedX = 3;
        this.speedY = 0;
    }

    public abstract void tick();
    public abstract void render(Canvas canvas);

    public void setX(int x) {
        this.posX = x;
    }
    public int getX() {return posX;}

    public void setY(int y) {
        this.posY = y;
    }
    public int getY() {return posY;}
    public void setSpeedY(int spdY) {this.speedY = spdY;}
}