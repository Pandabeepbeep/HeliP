package com.bipro.myhelipfinal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class BackCloud extends GameObject{
    Context context;
    Bitmap cloud;

    public BackCloud(int posX, int posY, int sizeX, int sizeY,int type,Context context) {
        super(posX, posY, GameObjectID.BACKGROUND, sizeX, sizeY);
        this.context = context;
        if(type ==0)
            cloud = BitmapFactory.decodeResource(context.getResources(),R.drawable.cloud);
        else if(type ==1)
            cloud = BitmapFactory.decodeResource(context.getResources(),R.drawable.cloud2);
        else if(type ==2)
            cloud = BitmapFactory.decodeResource(context.getResources(),R.drawable.cloud3);
        else if(type ==3)
            cloud = BitmapFactory.decodeResource(context.getResources(),R.drawable.cloud4);
        else
            cloud = BitmapFactory.decodeResource(context.getResources(),R.drawable.cloud5);
    }

    @Override
    public void tick() {
        posX -= 10;
    }

    @Override
    public void render(Canvas canvas) {
        canvas.drawBitmap(cloud,posX,posY,null);
    }
}
