package com.bipro.myhelipfinal;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;


public class Barrier extends GameObject {
    private int health;
    Paint barrierPaint;
    public Barrier(int posX, int posY, int size) {
        super(posX, posY, GameObject.GameObjectID.BARRIER, size, 10);
        health = 20;
        speedX = 0;
        speedY = 0;
        barrierPaint = new Paint();
        barrierPaint.setColor(Color.BLACK);
    }

    public int getHealth() {
        return health;
    }

    public void decHealth(int val) {
        health -= val;
    }

    public void tick() {
    }
    public void render(Canvas canvas) {
        canvas.drawRect(this.posX, (this.posY), this.posX + this.sizeX,
                this.posY + this.sizeY, barrierPaint);
    }
}
