package com.bipro.myhelipfinal;

import android.content.Context;

import java.io.*;

public class DiffSetting {
    public enum DIFFICULTY {EASY, MEDIUM, HARD}

    private final int[] settingVal;

    public DiffSetting(DIFFICULTY currDiff, Context context) {

        settingVal = new int[7];

        this.setDiff(currDiff,context);
    }

    public void setDiff(DIFFICULTY currDiff,Context context) {
        String path = null;
        if(currDiff == DIFFICULTY.EASY) {
            path = "Easy.txt";
        }
        else if(currDiff == DIFFICULTY.MEDIUM) {
            path = "Medium.txt";
        }
        else if(currDiff == DIFFICULTY.HARD) {
            path = "Hard.txt";
        }

        int i = 0;
        try {
            InputStream inputStream = context.getAssets().open("Settings/" + path);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = reader.readLine()) != null) {
                String[] tmp = line.split(" ", 0);
                settingVal[i] = Integer.parseInt(tmp[1]);
                i++;
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public int getSeed() {
        return settingVal[0];
    }
    public int getNEnemy() {
        return settingVal[1];
    }
    public int getNBarrier() {
        return settingVal[2];
    }
    public int getBulletVel() {
        return settingVal[3];
    }
    public int getBulletProb() {
        return settingVal[4];
    }
    public int getHelperProb() {
        return settingVal[5];
    }
    public int getUpdateTime() {
        return settingVal[6];
    }
}
