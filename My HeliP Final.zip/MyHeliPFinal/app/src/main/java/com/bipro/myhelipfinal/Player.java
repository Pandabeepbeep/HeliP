package com.bipro.myhelipfinal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class    Player extends GameObject {
    int health = 20;
    Bitmap player;
    int size = 32;
    Context context;

    public Player(Context context,int size) {
        super(GameView.dWidth/2 , GameView.dHeight - 100, GameObject.GameObjectID.PLAYER, size, size);
        player = BitmapFactory.decodeResource(context.getResources(),R.drawable.player256fl);
        this.context = context;
    }

    public void tick() {

    }

    @Override
    public void render(Canvas canvas) {
        canvas.drawBitmap(player,posX,posY,null);
    }


    public int getHealth() {
        return this.health;
    }

    public void decHealth(int dec) {
        this.health = Math.max(health - dec, 0);
    }

    public void incHealth(int inc) {
        this.health = Math.min(health + inc, 20);
    }

    public boolean isAlive() {
        return (health > 0);
    }
    public int getWidth(){
        return size;
    }
    public int getHeight(){
        return size;
    }
}
