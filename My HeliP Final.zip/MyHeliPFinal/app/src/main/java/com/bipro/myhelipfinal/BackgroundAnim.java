package com.bipro.myhelipfinal;

import static com.bipro.myhelipfinal.GameView.dHeight;
import static com.bipro.myhelipfinal.GameView.dWidth;

import android.content.Context;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

public class BackgroundAnim extends View {
    Context context;
    Paint backPaint, star;
    Canvas canvas;
    int time;
    int[][] rand, rX, rY;
    Random random;
    double timer = 0;
    int type = 0,cloudnum = 100;
    ArrayList<BackCloud> cloud;

    public BackgroundAnim(Context context) {
        super(context);
        this.context = context;
        backPaint = new Paint();
        star = new Paint();
        random = new Random();
        rX = new int[8][12];
        rY = new int[8][12];
        rand = new int[8][12];
        time = (int) System.currentTimeMillis() / 1000;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 12; j++) {
                rY[i][j] = random.nextInt(100);
                rX[i][j] = random.nextInt(100);
                rand[i][j] = random.nextInt(2);
            }
        }
        cloud = new ArrayList<>(1000);
        for(int c = 0;c<100;c++){
            if(random.nextInt(200)<20) {
                BackCloud cl = new BackCloud(random.nextInt(dWidth), random.nextInt(dHeight / 2), 32, 32, random.nextInt(5), context);
                cloud.add(cl);
            }
        }
    }

    public void render(Canvas canvas) {
        if (type == 0) {
            backPaint.setColor(Color.GRAY);
            star.setColor(Color.YELLOW);

            this.canvas = canvas;
            canvas.drawRect(0, 0, dWidth, dHeight, backPaint);
            int time1 = (int) System.currentTimeMillis() / 1000;

            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 12; j++) {

                    if (rand[i][j] == 1) {
                        if ((time1 - time >= 4) && (time1 - time <= 10)) {
                            canvas.drawCircle(((float) dWidth / 8) * i + rX[i][j], ((float) dHeight / 16) * j + rY[i][j], (float) (0.001 * (timer--)), star);
                        } else
                            canvas.drawCircle(((float) dWidth / 8) * i + rX[i][j], ((float) dHeight / 16) * j + rY[i][j], (float) (0.001 * (timer++)), star);
                    }
                }
            }

            if (time1 - time == 10) {
                rand = new int[8][12];
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 12; j++) {
                        rY[i][j] = random.nextInt(100);
                        rX[i][j] = random.nextInt(100);
                        rand[i][j] = random.nextInt(2);
                    }
                }
                time = time1;
                timer = 0;
            }
        }
        else {
            time = (int) System.currentTimeMillis() / 1000;
            backPaint.setColor(Color.CYAN);
            this.canvas = canvas;
            canvas.drawRect(0, 0, dWidth, dHeight, backPaint);
            //int time1 = (int) System.currentTimeMillis() / 1000;
            cloudnum = cloud.size();
            for(int i = 0;i<cloudnum;i++){
                cloud.get(i).render(canvas);
                cloud.get(i).tick();
            }
            if(random.nextInt(200)<10){
                BackCloud c = new BackCloud(dWidth + random.nextInt(100),random.nextInt(dHeight/2),32,32,random.nextInt(5),context);
                cloudnum++;
                cloud.add(c);
            }
        }
    }
}
