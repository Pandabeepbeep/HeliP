package com.bipro.myhelipfinal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Helper extends GameObject{
    private final boolean faceEast;
    Bitmap helperb;

    public Helper(int posX, int posY, int size, int initDirec, Context context) {
        super(posX, posY, GameObject.GameObjectID.HELPER, size, size);

        if(initDirec == 0) {
            faceEast = true;
            helperb = BitmapFactory.decodeResource(context.getResources(),R.drawable.helperhelicopter256fr);
        }
        else {
            faceEast = false;
            helperb = BitmapFactory.decodeResource(context.getResources(),R.drawable.helperhelicopter256fl);
        }

        speedX = 10;
        speedY = 0;
    }

    public void tick() {
        if(faceEast) {
            posX += speedX;
        }
        else {
            posX -= speedX;
        }
    }

    public void render(Canvas canvas) {
        canvas.drawBitmap(helperb,posX,posY,null);
    }
}
