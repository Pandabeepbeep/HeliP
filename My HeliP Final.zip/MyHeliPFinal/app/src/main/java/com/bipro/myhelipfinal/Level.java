package com.bipro.myhelipfinal;

import android.content.Context;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

public class Level {
    private final int dWidth;
    private final int dHeight;
    ArrayList<Enemy> enemies;
    ArrayList<Barrier> barriers;
    ArrayList<Bullet> bullets;

    ArrayList<Helper> helpers;
    ArrayList<MedicPack> medics;

    private final Random r;

    private static int currLevel;
    static int nEnemies, nBarriers, vBullet, dmgBullet;
    static int bulletProb, helperProb;

    public Level(int seed, int initialEnemies, int initialBarriers, int bulletVel, int bulletProb, int helperProb, int hitDamage,Context context) {
        dWidth = GameView.dWidth;
        dHeight = GameView.dHeight;

        currLevel = 0;
        nEnemies = initialEnemies;
        nBarriers = initialBarriers;
        vBullet = bulletVel;
        dmgBullet = hitDamage;

        Level.bulletProb = bulletProb;
        Level.helperProb = helperProb;

        r = new Random();
        bullets = new ArrayList<>();
        helpers = new ArrayList<>();
        medics = new ArrayList<>();



        genNextLevel(context);
    }

    public int currLevel() {
        return currLevel;
    }

    public void genNextLevel(Context context) {
        currLevel++;

        int[] settingVal = new int[6];

        int i = 0;
        try {
                InputStream inputStream = context.getAssets().open("Settings/Level-" + (currLevel) + ".txt");
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    String[] tmp = line.split(" ", 0);
                    settingVal[i] = Integer.parseInt(tmp[1]);
                    i++;
                }

                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        nEnemies = settingVal[0];
        nBarriers = settingVal[1];
        vBullet = settingVal[2];
        dmgBullet = 10;

        bulletProb = settingVal[3];
        helperProb = settingVal[4]/10;

        enemies = genEnemies(context);
        barriers = genBarriers();
    }
    public ArrayList<Enemy> genEnemies(Context context) {
        enemies = new ArrayList<>();

        for(int i = 0; i < nEnemies; i++) {
            Enemy enemy = new Enemy(r.nextInt(dWidth),100 +r.nextInt(dHeight/4),64,r.nextBoolean(),context);
            enemies.add(enemy);
        }
        return enemies;
    }

    public ArrayList<Barrier> genBarriers() {
        barriers = new ArrayList<>();

        for(int i = 0; i < nBarriers; i++) {
            Barrier barrier = new Barrier(r.nextInt(dWidth), 3*dHeight/5 + (r.nextInt(5)*70),64);
            barriers.add(barrier);
        }

        return barriers;
    }

    public void genBullets(Context context,ArrayList<Bullet> bullets) {
            //int bulletsCountPerUpdate = 0;
            if(bulletProb > r.nextInt(10000)) {
                //bulletsCountPerUpdate++;
                Bullet b = new Bullet(enemies.get(r.nextInt(enemies.size())).posX + GameUtil.getRandom(0, 10), enemies.get(r.nextInt(enemies.size())).posY, 16,context);
                b.setSpeedY(vBullet*5);
                bullets.add(b);
            }
    }

    public ArrayList<Barrier> getBarriers() {
        return barriers;
    }
    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }

}
