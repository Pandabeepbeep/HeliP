package com.bipro.myhelipfinal;


import java.util.ArrayList;

public class Game {
    public static void checkCollision(Player player, ArrayList<Barrier> b, Bullet bullet) {
        int Xp = player.posX - player.getWidth()/2;
        int Yp = player.posY - player.getHeight()/4;

        int Xb = bullet.posX;
        int Yb = bullet.posY;


        boolean collided = false;
        if(Xp > Xb && Xp - Xb < bullet.bulletPic.getWidth()) {
            if(Yp > Yb && Yp - Yb < bullet.bulletPic.getHeight()) {
                collided = true;
            }
            else if(Yp < Yb && Yb - Yp < player.player.getWidth()) {
                collided = true;
            }
        }
        else if(Xp < Xb && Xb - Xp < player.player.getWidth()) {
            if(Yp > Yb && Yp - Yb < bullet.bulletPic.getHeight()) {
                collided = true;
            }
            else if(Yp < Yb && Yb - Yp < player.player.getWidth()) {
                collided = true;
            }
        }

        if(collided) {
            bullet.setX(GameView.dWidth + 50);
            bullet.setY(GameView.dHeight + 50);
            player.decHealth(5);
        }

        for(int c =0;c<b.size();c++) {
            int X = b.get(c).posX;
            int Y = b.get(c).posY;

            collided = false;
            if(X > Xb && X - Xb < bullet.bulletPic.getWidth()) {
                if(Y > Yb && Y - Yb < bullet.bulletPic.getHeight()) {
                    collided = true;
                }
                else if(Y < Yb && Yb - Y < b.get(c).sizeY) {
                    collided = true;
                }
            }
            else if(X < Xb && Xb - X < b.get(c).sizeX) {
                if(Y > Yb && Y - Yb < bullet.bulletPic.getHeight()) {
                    collided = true;
                }
                else if(Y < Yb && Yb - Y < b.get(c).sizeY) {
                    collided = true;
                }
            }

            if(collided) {
                bullet.setX(GameView.dWidth + 50);
                bullet.setY(GameView.dHeight + 50);
                b.get(c).decHealth(5);
            }
        }
    }
    public static void checkHealing(Player player, MedicPack medic) {
        int Xp = player.posX - player.getWidth()/2;
        int Yp = player.posY - player.getHeight()/4;

        int Xm = medic.posX - medic.medicb.getWidth()/2;
        int Ym = medic.posY - medic.medicb.getHeight()/2;

        boolean collided = false;
        if(Xp > Xm && Xp - Xm < medic.medicb.getWidth()) {
            if(Yp > Ym && Yp - Ym < medic.medicb.getHeight()) {
                collided = true;
            }
            else if(Yp < Ym && Ym - Yp < player.player.getHeight()) {
                collided = true;
            }
        }
        else if(Xp < Xm && Xm - Xp < player.player.getWidth()) {
            if(Yp > Ym && Yp - Ym < medic.medicb.getHeight()) {
                collided = true;
            }
            else if(Yp < Ym && Ym - Yp < player.player.getHeight()) {
                collided = true;
            }
        }

        if(collided) {
            medic.setX(GameView.dWidth + 50);
            medic.setY(GameView.dHeight + 50);
            player.incHealth(5);
        }
    }
}

