package com.bipro.myhelipfinal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Bullet extends GameObject {
    Bitmap bulletPic;
    int sizeof;
    public Bullet(int posX, int posY, int size,Context context) {

        super(posX, posY, GameObject.GameObjectID.BULLET, size, size);
        bulletPic = BitmapFactory.decodeResource(context.getResources(), R.drawable.bullet256fd);
        this.sizeof = size;
        speedX = 0;
        speedY = 1;
    }

    public void tick() {
        posY += speedY;
    }
    public void setSpeedY(int vel){
        speedY = vel;
    }

    @Override
    public void render(Canvas canvas) {
        canvas.drawBitmap(bulletPic,this.posX,this.posY,null);
    }
}