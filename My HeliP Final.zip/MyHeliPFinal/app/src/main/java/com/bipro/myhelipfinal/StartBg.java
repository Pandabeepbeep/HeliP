package com.bipro.myhelipfinal;

import static com.bipro.myhelipfinal.GameView.dHeight;
import static com.bipro.myhelipfinal.GameView.dWidth;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.content.res.ResourcesCompat;

import java.util.Random;

public class StartBg extends View {
    int[][] rand, rX, rY;
    Random random;
    Context context;
    Canvas canvas;

    int time,viewHeight,viewWidth,timer = 0;
    Paint backPaint = new Paint(),star = new Paint();


    public StartBg(Context context) {
        super(context);
        this.context = context;

        random = new Random();
        rX = new int[8][12];
        rY = new int[8][12];
        rand = new int[8][12];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 12; j++) {
                rY[i][j] = random.nextInt(100);
                rX[i][j] = random.nextInt(100);
                rand[i][j] = random.nextInt(2);
            }
        }
        time = (int) System.currentTimeMillis() / 1000;
        //View myView = findViewById(R.id.customDrawView);
        //viewWidth = myView.getWidth();
        //viewHeight = myView.getHeight();
    }

    public StartBg(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;

        random = new Random();
        rX = new int[8][12];
        rY = new int[8][12];
        rand = new int[8][12];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 12; j++) {
                rY[i][j] = random.nextInt(100);
                rX[i][j] = random.nextInt(100);
                rand[i][j] = random.nextInt(2);
            }
        }
        time = (int) System.currentTimeMillis() / 1000;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        /*text.setColor(Color.BLACK);
        text.setTextSize(100);
        text.setTextAlign(Paint.Align.CENTER);
        text.setStyle(Paint.Style.FILL);


        canvas.drawText("Wow",100,100,text);*/

        backPaint.setColor(Color.GRAY);
        star.setColor(Color.YELLOW);

        this.canvas = canvas;
        canvas.drawRect(0, 0, dWidth, dHeight, backPaint);
        int time1 = (int) System.currentTimeMillis() / 1000;
        System.out.println(time1-time);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 12; j++) {

                if (rand[i][j] == 1) {
                    if ((time1 - time >= 4) && (time1 - time <= 10)) {
                        canvas.drawCircle(((float) dWidth / 8) * i + rX[i][j], ((float) dHeight / 16) * j + rY[i][j], (float) (0.001 * (timer--)), star);
                    } else
                        canvas.drawCircle(((float) dWidth / 8) * i + rX[i][j], ((float) dHeight / 16) * j + rY[i][j], (float) (0.001 * (timer++)), star);
                }
            }
        }

        if (time1 - time == 10) {
            rand = new int[8][12];
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 12; j++) {
                    rY[i][j] = random.nextInt(100);
                    rX[i][j] = random.nextInt(100);
                    rand[i][j] = random.nextInt(2);
                }
            }
            time = time1;
            timer = 0;
        }
    }
}