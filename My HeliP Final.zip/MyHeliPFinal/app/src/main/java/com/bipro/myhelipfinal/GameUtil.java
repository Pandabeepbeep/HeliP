package com.bipro.myhelipfinal;

import java.util.Random;

public class GameUtil {
    private static final Random random = new Random();
    public static int getRandom(int l, int h) {
        return l + random.nextInt(h - l + 1);
    }
}
