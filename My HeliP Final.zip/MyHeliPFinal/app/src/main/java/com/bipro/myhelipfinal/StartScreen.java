package com.bipro.myhelipfinal;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;


public class StartScreen extends AppCompatActivity {
    ScoreView scoreView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_screen);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        initia();
    }
    public void initia(){
        if(getIntent().getExtras()!=null){
            String text1 = getIntent().getExtras().getString(("Diff"));
            TextView text = findViewById(R.id.Diff);
            if(text1.contains("Easy"))
                text.setText("Difficulty : Easy");
            else if(text1.contains("Medium"))
                text.setText("Difficulty : Medium");
            else
                text.setText("Difficulty : Hard");
        }
        else{
            TextView text = findViewById(R.id.Diff);
            text.setText("Difficulty : Easy");
        }
    }

    public void Settings(View view){
        findViewById(R.id.Play).setVisibility(View.GONE);
        findViewById(R.id.ScoreCard).setVisibility(View.GONE);
        findViewById(R.id.Exit).setVisibility(View.GONE);
        findViewById(R.id.Settings).setVisibility(View.GONE);
        findViewById(R.id.Story).setVisibility(View.GONE);
        findViewById(R.id.Mode1).setVisibility(View.VISIBLE);
        findViewById(R.id.Mode2).setVisibility(View.VISIBLE);
        findViewById(R.id.Mode3).setVisibility(View.VISIBLE);
        findViewById(R.id.Back).setVisibility(View.VISIBLE);
        findViewById(R.id.textLay).setVisibility(View.GONE);
    }
    public void showStory(View view){
        findViewById(R.id.Play).setVisibility(View.GONE);
        findViewById(R.id.ScoreCard).setVisibility(View.GONE);
        findViewById(R.id.Exit).setVisibility(View.GONE);
        findViewById(R.id.Settings).setVisibility(View.GONE);
        findViewById(R.id.Story).setVisibility(View.GONE);
        findViewById(R.id.ScrollStory).setVisibility(View.VISIBLE);
        findViewById(R.id.Back).setVisibility(View.VISIBLE);
        findViewById(R.id.textLay).setVisibility(View.GONE);
    }
    public void Back(View view){
        findViewById(R.id.textLay).setVisibility(View.VISIBLE);
        findViewById(R.id.Play).setVisibility(View.VISIBLE);
        findViewById(R.id.ScoreCard).setVisibility(View.VISIBLE);
        findViewById(R.id.Exit).setVisibility(View.VISIBLE);
        findViewById(R.id.Settings).setVisibility(View.VISIBLE);
        findViewById(R.id.Story).setVisibility(View.VISIBLE);
        findViewById(R.id.Mode1).setVisibility(View.GONE);
        findViewById(R.id.Mode2).setVisibility(View.GONE);
        findViewById(R.id.Mode3).setVisibility(View.GONE);
        findViewById(R.id.ScrollStory).setVisibility(View.GONE);
        findViewById(R.id.Back).setVisibility(View.GONE);
    }
    public void Exit(View view){

        System.exit(0);
    }
    public void Play(View view){
        TextView text = findViewById(R.id.Diff);
        String text1 = text.getText().toString();
        GameView gameView = new GameView(this,text1);
        setContentView(gameView);
    }

    public void clickEasy(View view) {
        TextView text = findViewById(R.id.Diff);
        text.setText("Difficulty : Easy");
        findViewById(R.id.textLay).setVisibility(View.VISIBLE);

        findViewById(R.id.Play).setVisibility(View.VISIBLE);
        findViewById(R.id.ScoreCard).setVisibility(View.VISIBLE);
        findViewById(R.id.Exit).setVisibility(View.VISIBLE);
        findViewById(R.id.Settings).setVisibility(View.VISIBLE);
        findViewById(R.id.Story).setVisibility(View.VISIBLE);
        findViewById(R.id.Mode1).setVisibility(View.GONE);
        findViewById(R.id.Mode2).setVisibility(View.GONE);
        findViewById(R.id.Mode3).setVisibility(View.GONE);
        findViewById(R.id.ScrollStory).setVisibility(View.GONE);
        findViewById(R.id.Back).setVisibility(View.GONE);
    }


    public void clickMed(View view) {
        TextView text = findViewById(R.id.Diff);
        text.setText("Difficulty : Medium");
        findViewById(R.id.textLay).setVisibility(View.VISIBLE);
        findViewById(R.id.Play).setVisibility(View.VISIBLE);
        findViewById(R.id.ScoreCard).setVisibility(View.VISIBLE);
        findViewById(R.id.Exit).setVisibility(View.VISIBLE);
        findViewById(R.id.Settings).setVisibility(View.VISIBLE);
        findViewById(R.id.Story).setVisibility(View.VISIBLE);
        findViewById(R.id.Mode1).setVisibility(View.GONE);
        findViewById(R.id.Mode2).setVisibility(View.GONE);
        findViewById(R.id.Mode3).setVisibility(View.GONE);
        findViewById(R.id.ScrollStory).setVisibility(View.GONE);
        findViewById(R.id.Back).setVisibility(View.GONE);
    }

    public void clickHard(View view) {
        TextView text = findViewById(R.id.Diff);
        text.setText("Difficulty : Hard");
        findViewById(R.id.textLay).setVisibility(View.VISIBLE);
        findViewById(R.id.Play).setVisibility(View.VISIBLE);
        findViewById(R.id.ScoreCard).setVisibility(View.VISIBLE);
        findViewById(R.id.Exit).setVisibility(View.VISIBLE);
        findViewById(R.id.Settings).setVisibility(View.VISIBLE);
        findViewById(R.id.Story).setVisibility(View.VISIBLE);
        findViewById(R.id.Mode1).setVisibility(View.GONE);
        findViewById(R.id.Mode2).setVisibility(View.GONE);
        findViewById(R.id.Mode3).setVisibility(View.GONE);
        findViewById(R.id.ScrollStory).setVisibility(View.GONE);
        findViewById(R.id.Back).setVisibility(View.GONE);
    }

    public void Scorecard(View view) {
        TextView text = findViewById(R.id.Diff);
        String text1 = text.getText().toString();
        scoreView = new ScoreView(this,text1);
        setContentView(scoreView);
    }
}
