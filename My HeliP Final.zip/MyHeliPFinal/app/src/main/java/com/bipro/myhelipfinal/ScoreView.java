package com.bipro.myhelipfinal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Handler;
import android.util.TypedValue;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ScoreView extends View {

    Context context;
    int dWidth,dHeight;
    Handler handler;
    Runnable runnable;
    Paint buttonPaint = new Paint();
    Paint buttonPaintE,buttonPaintM= new Paint(),buttonPaintH= new Paint(),clearPaint = new Paint();
    String textdiff;
    Bitmap close1;
    int scale,gap1,gap2;
    String finalStr,setDiff;
    public ScoreView(Context context, String text) {
        super(context);
        this.context = context;
        textdiff = text;
        Display display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        dWidth = size.x;
        dHeight = size.y;
        handler = new Handler();
        runnable = this::invalidate;
        buttonPaint.setColor(Color.BLUE);
        buttonPaint.setTextSize(120);
        buttonPaint.setTextAlign(Paint.Align.CENTER);
        clearPaint.setColor(Color.RED);
        clearPaint.setTextSize(60);
        clearPaint.setTextAlign(Paint.Align.CENTER);
        buttonPaintE = buttonPaint;
        buttonPaintE.setColor(Color.BLACK);
        buttonPaintM.setColor(Color.BLUE);
        buttonPaintH.setColor(Color.BLUE);
        Bitmap close = BitmapFactory.decodeResource(context.getResources(),R.drawable.close256);
        scale = spToPx(80,context);
        gap1 = spToPx(20,context);
        gap2 = spToPx(10,context);
        close1 = Bitmap.createScaledBitmap(close, scale, scale, false);

    }
    public void onDraw(Canvas canvas){
        super.onDraw(canvas);
        canvas.drawRect(30,dHeight - 300,dWidth/3 -10,dHeight-120,buttonPaintE);
        canvas.drawRect(dWidth/3 +20,dHeight - 300,(2*dWidth/3) -20,dHeight-120,buttonPaintM);
        canvas.drawRect((2*dWidth/3) +10,dHeight - 300,dWidth -30,dHeight-120,buttonPaintH);
        canvas.drawBitmap(close1,dWidth-scale-gap2,gap1,null);
        canvas.drawText("Clear Score",150,60,clearPaint);
        int i = 0;
        try {
            InputStream inputStream = context.openFileInput("ScoreCard.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            StringBuilder result = new StringBuilder();
            result.append('\n');
            result.append("Score");
            /*if (reader.readLine() == null ||reader.readLine() == " ") {
                finalStr = "Noscoresyet.\n Tryagain\n";
            }
            else {*/
                while ((line = reader.readLine()) != null) {
                    //if (result.length() > 0) {
                        result.append('\n');
                    //}
                    result.append(line);
                }
                System.out.println(result);
                finalStr = result.toString();

                reader.close();
            //}
            } catch(IOException e){
                e.printStackTrace();
            }
        int x = dWidth/2, y = 0;
        for (String line :finalStr.split("\n")){
            canvas.drawText(line, x, y, buttonPaint);
            y += buttonPaint.descent() - buttonPaint.ascent();
        }
    }

    public boolean onTouchEvent(MotionEvent event){
        float touchX = event.getX();
        float touchY = event.getY();
        float oldY;
        if(touchX>=dWidth-scale-gap2&&touchX<=dWidth-gap2){
            if(touchY>=gap1 && touchY<=scale+gap1){
                startScreen();
            }
        }
        if(touchX>=30 && touchX<=dWidth/3 -10){
            if(touchY>=dHeight - 300 && touchY<=dHeight-120){
                setDiff = "Easy";
                invalidate();
                buttonPaintE.setColor(Color.BLACK);
                buttonPaintM.setColor(Color.BLUE);
                buttonPaintH.setColor(Color.BLUE);
            }
        }
        else if(touchX>=dWidth/3 +20 && touchX<=(2*dWidth/3) -20){
            if(touchY>=dHeight - 300 && touchY<=dHeight-120){
                setDiff = "Medium";
                invalidate();
                buttonPaintM.setColor(Color.BLACK);
                buttonPaintE.setColor(Color.BLUE);
                buttonPaintH.setColor(Color.BLUE);

            }
        }
        else if(touchX>=((2*dWidth/3) +10) && touchX<=(dWidth)){
            if(touchY>=dHeight - 300 && touchY<=dHeight-120){
                setDiff = "Hard";
                invalidate();
                buttonPaintH.setColor(Color.BLACK);
                buttonPaintE.setColor(Color.BLUE);
                buttonPaintM.setColor(Color.BLUE);
            }
        }
        if(touchY>=20 && touchY<=(20+60) && touchX >=0 && touchX <=300) {
            try {
                FileOutputStream out = context.openFileOutput("ScoreCard.txt", 0);
                String nw = "";
                byte[] a = nw.getBytes();
                out.write(a);
                startScreen();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        /*else{
            int action = event.getAction();
            if (action == MotionEvent.ACTION_DOWN) {
                oldY = event.getY();
                oldPlayerX = playerX;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                float shift = oldX - touchX;
                float newPlayerX = oldPlayerX - shift;
                if (newPlayerX <= 0) {
                    playerX = 0;
                } else if (newPlayerX >= dWidth - player.getWidth())
                    playerX = dWidth - player.getWidth();
                else
                    playerX = (int) newPlayerX;
            }
        }*/

        return false;
    }
    public void startScreen(){
        Intent intent = new Intent(context,StartScreen.class);
        intent.putExtra("Diff",textdiff);
        context.startActivity(intent);
        ((Activity) context).finish();
    }
    public static int spToPx(float sp, Context context) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, context.getResources().getDisplayMetrics());
    }
}
