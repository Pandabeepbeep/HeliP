package com.bipro.myhelipfinal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;

import android.os.Handler;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.content.res.ResourcesCompat;

import java.io.FileOutputStream;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Random;

public class GameView extends View {

    Context context;
    Handler handler;
    final long UPDATE_MILLIS = 15;
    Runnable runnable;
    ArrayList<Enemy> enemies;
    ArrayList<Bullet>[] b;
    ArrayList<Helper> helpers;
    ArrayList<MedicPack> medics;
    ArrayList<Barrier> barriers;
    static int dWidth,dHeight;
    Player player;
    Paint textPaint = new Paint();
    Paint headerPaint = new Paint();
    Paint healthPaint = new Paint();
    Paint nullPaint = new Paint();
    Paint healthPaintBack = new Paint();
    Paint barrierPaint = new Paint();
    Random random;
    float oldX,oldPlayerX,TEXT_SIZE = 100;
    float playerX,playerY;
    int life;
    int points = 0;
    private static Level level;
    BackgroundAnim back;
    int time;
    Paint backPaint;
    Paint star;
    Intent intent;
    Bitmap close1;

    String diff = "Difficulty : Easy";
    String diffEasy  = "Difficulty : Easy";
    String diffMed  = "Difficulty : Medium";
    String diffHard  = "Difficulty : Hard";
    public GameView(Context context,String diff1) {
        super(context);
        this.context = context;
        this.diff = diff1;
        DiffSetting ds;
        if(diff == diffEasy) {
            ds = new DiffSetting(DiffSetting.DIFFICULTY.EASY, context);
            System.out.println("Easy");
            System.out.println(diff);
        }
        else if(diff == diffMed) {
            ds = new DiffSetting(DiffSetting.DIFFICULTY.MEDIUM, context);
            System.out.println("Medium");
            System.out.println(diff);
        }
        else {
            ds = new DiffSetting(DiffSetting.DIFFICULTY.HARD, context);
            System.out.println("Hard");
            System.out.println(diff);
        }
        Display display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        dWidth = size.x;
        dHeight = size.y;
        handler = new Handler();
        runnable = this::invalidate;
        textPaint.setColor(Color.rgb(0,0,0));
        textPaint.setTextSize(TEXT_SIZE);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTypeface(ResourcesCompat.getFont(context,R.font.pressstart2p));
        headerPaint.setColor(Color.rgb(0,0,0));
        headerPaint.setTextSize(50);
        headerPaint.setTextAlign(Paint.Align.CENTER);
        headerPaint.setTypeface(ResourcesCompat.getFont(context,R.font.pressstart2p));
        healthPaint.setColor(Color.GREEN);
        healthPaintBack.setColor(Color.BLACK);
        nullPaint.setColor(Color.WHITE);
        barrierPaint.setColor(Color.rgb(0,0,0));
        random = new Random();

        level = new Level(ds.getSeed(), ds.getNEnemy(), ds.getNBarrier(), ds.getBulletVel(), ds.getBulletProb(), ds.getHelperProb(),
                10,context);
        enemies = new ArrayList<>();
        enemies = level.getEnemies();
        barriers = new ArrayList<>();
        barriers = level.getBarriers();
        b = new ArrayList[enemies.size()];
        for(int k = 0;k<enemies.size();k++) {
            b[k] = enemies.get(k).bullets;
        }
        player = new Player(context,32);
        playerX = (float)dWidth/2 - (float)player.getWidth()/2;
        playerY = dHeight - player.getHeight()-200;
        helpers = new ArrayList<>();
        medics = new ArrayList<>();
        back = new BackgroundAnim(context);
        time = (int) (System.currentTimeMillis()/1000);
        backPaint = new Paint(Color.BLUE);
        star = new Paint(Color.YELLOW);
        intent = new Intent(context, GameView.class);
        Bitmap close = BitmapFactory.decodeResource(context.getResources(),R.drawable.close256);
        close1 = Bitmap.createScaledBitmap(close, 64, 64, false);
    }

    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        life = player.getHealth();
        if(life == 0){
            gameOver();
        }
        else {
            back.render(canvas);
            player.render(canvas);
            canvas.drawBitmap(close1,dWidth -64,32,null);

            int time1 = (int) (System.currentTimeMillis() / 1000);
            if (time1 - time != 30) {
                for (int i = 0; i < enemies.size(); i++) {
                    canvas.drawBitmap(enemies.get(i).enemyHeli, enemies.get(i).posX, enemies.get(i).posY, null);
                    enemies.get(i).tick();
                    if (b[i].size() > 0) {
                        for (int j = 0; j < b[i].size(); j++) {
                            b[i].get(j).render(canvas);
                            b[i].get(j).tick();
                            Game.checkCollision(player, barriers, b[i].get(j));

                            //To not count points if blocked by barrier
                    /*if(b[i].get(j).posY<=dHeight-100 && b[i].get(j).posY>=dHeight-105){
                    points += 10;
                    b[i].remove(j);
                    }
                    else if(b[i].get(j).posY>dHeight-100) {
                        b[i].remove(j);

                    }*/
                            if (b[i].get(j).posY > dHeight - 100) {
                                b[i].remove(j);
                                points += 10;
                            }
                        }

                    } else {
                        level.genBullets(context, b[i]);
                    }
                    player.posX = (int) playerX;
                    player.posY = (int) playerY;

                }


                for (int j = 0; j < barriers.size(); j++) {
                    barriers.get(j).render(canvas);
                    if (barriers.get(j).getHealth() < 1) {
                        barriers.remove(j);
                    }
                }
                int helperProb = Level.helperProb;
                if (random.nextInt(2) == 1) {
                    if (helperProb > random.nextInt(10000)) {
                        helpers.add(new Helper(GameUtil.getRandom(32, dWidth - 32), GameUtil.getRandom(100, 150), 40, 0, context));
                        medics.add(new MedicPack(helpers.get(helpers.size() - 1).getX(), helpers.get(helpers.size() - 1).getY(), 25, context));
                    }
                } else {
                    if (helperProb > random.nextInt(10000)) {
                        helpers.add(new Helper(GameUtil.getRandom(32, dWidth - 32), GameUtil.getRandom(100, 150), 40, 1, context));
                        medics.add(new MedicPack(helpers.get(helpers.size() - 1).getX(), helpers.get(helpers.size() - 1).getY(), 25, context));
                    }
                }
                for (int h = 0; h < helpers.size(); h++) {
                    helpers.get(h).render(canvas);
                    helpers.get(h).tick();

                }
                for (int m = 0; m < medics.size(); m++) {
                    medics.get(m).render(canvas);
                    medics.get(m).tick();
                    Game.checkHealing(player, medics.get(m));
                }
            } else {

                level.genNextLevel(context);
                this.enemies = level.getEnemies();
                this.barriers = level.getBarriers();
                b = new ArrayList[enemies.size()];
                for (int k = 0; k < enemies.size(); k++) {
                    b[k] = enemies.get(k).readBullet();
                    back.type = random.nextInt(3);
                }
                time = time1;
            }
            GameStats(canvas);
        }
    }
    public void GameStats(Canvas canvas){
        canvas.drawRect(28,130,234,186,healthPaintBack);
        canvas.drawRect(32,132,232,182,nullPaint);
        canvas.drawRect(32,132,(32+10*life),182,healthPaint);
        canvas.drawText("Health", 160, 80,headerPaint);
        canvas.drawText("Points", dWidth-260, 80,headerPaint);
        if(points == 0){
            canvas.drawText("" + points, dWidth-200, TEXT_SIZE + 100,textPaint);
        }
        else {
            for (int p = 10; p > 0; p--) {
                if (points >= Math.pow(10, p)) {
                    canvas.drawText("" + points, dWidth - 300 - (100 * (p - 1)), TEXT_SIZE +100, textPaint);
                    break;
                }
            }
        }
        canvas.drawText("Level", (float)dWidth/2, 80,headerPaint);
        canvas.drawText("" + level.currLevel(), (float)dWidth/2, TEXT_SIZE+50,headerPaint);
        handler.postDelayed(runnable,UPDATE_MILLIS);
    }

    public boolean onTouchEvent(MotionEvent event){
        float touchX = event.getX();
        float touchY = event.getY();
        if(touchX>=dWidth-96&&touchX<=dWidth-32){
            if(touchY>=32 && touchY<=96){
                gameOver();
            }
        }
        else if(touchY>=playerY){
            int action = event.getAction();
            if(action == MotionEvent.ACTION_DOWN){
                oldX = event.getX();
                oldPlayerX = playerX;
            }
            if(action == MotionEvent.ACTION_MOVE){
                float shift = oldX - touchX;
                float newPlayerX = oldPlayerX - shift;
                if(newPlayerX<=0){
                    playerX = 0;
                }
                else if (newPlayerX >= dWidth - player.getWidth())
                    playerX = dWidth - player.getWidth();
                else
                    playerX = (int) newPlayerX;
            }
        }
        return true;
    }
    public void gameOver(){
        try {

            FileOutputStream out = context.openFileOutput("ScoreCard.txt", Context.MODE_APPEND);
            String pointString = Integer.toString(points);
            String newLine = System.getProperty("line.separator");
            byte[] textByte = pointString.getBytes();
            byte[] newSep= newLine.getBytes();
            //out.write(newSep);
            out.write(textByte);
            out.write(newSep);
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent(context,GameOver.class);
        intent.putExtra("points",points);
        intent.putExtra("Diff",diff);
        context.startActivity(intent);
        ((Activity) context).finish();
    }
    public void startScreen(){
        Intent intent = new Intent(context,StartScreen.class);
        intent.putExtra("Diff",diff);
        context.startActivity(intent);
        ((Activity) context).finish();
    }
}


