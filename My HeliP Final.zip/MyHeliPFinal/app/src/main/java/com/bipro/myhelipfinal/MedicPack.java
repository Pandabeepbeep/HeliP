package com.bipro.myhelipfinal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class MedicPack extends GameObject {
    Bitmap medicb;
    public MedicPack(int posX, int posY, int size, Context context) {

        super(posX, posY, GameObject.GameObjectID.MEDIC, size, size);
        medicb = BitmapFactory.decodeResource(context.getResources(),R.drawable.pharmacy256);

        speedX = 0;
        speedY = 10;
    }

    public void tick() {
        posY += speedY;
    }

    public void render(Canvas canvas) {
        canvas.drawBitmap(medicb,posX,posY,null);
    }
}
