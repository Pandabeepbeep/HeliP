package com.bipro.myhelipfinal;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class GameOver extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_over);
        int points = getIntent().getExtras().getInt("points");
        TextView myTextView = findViewById(R.id.stat_2);
        myTextView.setText(String.valueOf(points));
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    public void startGame(View view){
        String diff1 = getIntent().getExtras().getString("Diff");
        String diff2;
        if(diff1.contains("Easy"))
            diff2 = "Difficulty : Easy";
        else if(diff1.contains("Medium"))
            diff2 = "Difficulty : Medium";
        else
            diff2 = "Difficulty : Hard";
        GameView gameView = new GameView(this,diff2);
        setContentView(gameView);
    }
    public void startScreen(View view){
        Intent intent = new Intent(GameOver.this, StartScreen.class);
        String diff = getIntent().getExtras().getString("Diff");
        intent.putExtra("Diff",diff);
        startActivity(intent);
        finish();
    }
}
