package com.bipro.myhelipfinal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import java.util.ArrayList;

public class Enemy extends GameObject{
    public boolean faceRight;
    Bitmap enemyHeli;
    ArrayList<Bullet> bullets;
    Context context;

    public Enemy(int posX, int posY, int size, boolean faceRight, Context context) {
        super(posX, posY, GameObject.GameObjectID.ENEMY, size, size);
        this.context = context;
        if(faceRight) {
            this.faceRight = true;
            enemyHeli = BitmapFactory.decodeResource(context.getResources(),R.drawable.enemyhelicopter256fr);
        }
        else {
            this.faceRight = false;
            enemyHeli = BitmapFactory.decodeResource(context.getResources(),R.drawable.enemyhelicopter256fl);
        }
        bullets = new ArrayList<>();
    }


    public ArrayList<Bullet> readBullet() {
        return bullets;
    }

    public void tick() {
        // System.out.println("Enemy tick()");

        if(this.faceRight) {
            if(this.posX + this.enemyHeli.getWidth() > GameView.dWidth) {
                this.faceRight = false;
                this.enemyHeli = BitmapFactory.decodeResource(context.getResources(),R.drawable.enemyhelicopter256fl);
                return;
            }
            this.posX += 5*this.speedX;
        }
        else {
            if(this.posX < 0) {
                this.faceRight = true;
                this.enemyHeli = BitmapFactory.decodeResource(context.getResources(),R.drawable.enemyhelicopter256fr);
                return;
            }
            this.posX -= 5*this.speedX;
        }

        /*for(int i = 0; i < bullets.size(); i++) {
            bullets.get(i).render(canvas);
            bullets.get(i).tick();
            Game.checkCollision(context, player, barriers, bullets.get(i));
                        //To not count points if blocked by barrier
                        //if(b[i].get(j).posY<=dHeight-100 && b[i].get(j).posY>=dHeight-105){
                        //points += 10;
                        //b[i].remove(j);
                        //}
                        //else if(b[i].get(j).posY>dHeight-100) {
                        //    b[i].remove(j);
                        //}
            if (bullets.get(i).posY > dHeight - 100) {
                Game.score+=10;
                bullets.remove(i);
            }
        }*/
    }

    @Override
    public void render(Canvas canvas) {
        canvas.drawBitmap(enemyHeli,posX,posY,null);
        for(GameObject go : bullets) {
            go.render(canvas);
        }
    }

}
